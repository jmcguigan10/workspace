class ProviderError(RuntimeError):
    pass
